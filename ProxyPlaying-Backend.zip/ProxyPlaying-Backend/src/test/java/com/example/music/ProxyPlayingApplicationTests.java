package com.example.music;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyPlayingApplicationTests {

	@Test
	void contextLoads() {
	}

}
