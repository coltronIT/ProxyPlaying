package com.example.music;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProxyPlayingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProxyPlayingApplication.class, args);
	}

}
