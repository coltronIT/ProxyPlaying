package com.example.music;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class CachedMusicService implements MusicService {

    private final Map<String, String> cache = new HashMap<>();
    private final ExpensiveMusicService expensiveMusicService;

    @Autowired
    public CachedMusicService(ExpensiveMusicService expensiveMusicService) {
        this.expensiveMusicService = expensiveMusicService;
    }

    @Override
    public String playSong(String songName) {
        return cache.computeIfAbsent(songName, k -> {
            System.out.println("Fetching and caching song: " + songName);
            return expensiveMusicService.playSong(songName);
        });
    }
}
