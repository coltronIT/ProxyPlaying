package com.example.music;

import org.springframework.stereotype.Service;

@Service
public class ExpensiveMusicService implements MusicService {

    @Override
    public String playSong(String songName) {
        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return "Playing" + songName + " from the high-quality music service...";
    }
}
