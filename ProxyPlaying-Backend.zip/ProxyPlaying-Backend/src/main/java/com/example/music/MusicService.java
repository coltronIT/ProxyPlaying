package com.example.music;

public interface MusicService {
    String playSong(String songName);
}
