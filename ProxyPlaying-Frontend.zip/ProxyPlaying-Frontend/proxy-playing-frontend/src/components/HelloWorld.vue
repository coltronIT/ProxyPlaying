<template>
  <div>
    <button @click="playSongDirectly">Play Directly (Expensive)</button>
    <button @click="playSongCached">Play Cached (Proxy)</button>
  </div>
</template>

<script>
import { ref } from 'vue';
import axios from 'axios';

export default {
  setup() {
    const songId = ref('123'); // replace with your actual song ID or a reactive property

    const playSongDirectly = async () => {
      try {
        const response = await axios.get(`/api/music/play/expensive/${songId.value}`);
        // Logic to play the song with the response data
      } catch (error) {
        console.error('An error occurred while trying to play the song directly.');
      }
    };

    const playSongCached = async () => {
      try {
        const response = await axios.get(`/api/music/play/cached/${songId.value}`);
        // Logic to play the song with the response data
      } catch (error) {
        console.error('An error occurred while trying to play the song from cache.');
      }
    };

    return {
      songId,
      playSongDirectly,
      playSongCached
    };
  }
};
</script>
